package com.example.text_based_rpg;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
