import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:text_based_rpg/models/character.dart';
import 'package:text_based_rpg/provider/character_provider.dart';
import 'package:text_based_rpg/screens/screen2.dart';
import 'package:text_based_rpg/screens/screen4.dart';


class Screen3 extends StatelessWidget {
  static String routeName = '/screen3';

  @override
  Widget build(BuildContext context) {
    CharacterProvider characterList = Provider.of<CharacterProvider>(context);
    List<Character> character = characterList.getCharacterList();

    return Scaffold(
      // appBar: AppBar(
      //   title: Text('Text based RPG'),
      // ),
      body: Stack(
        children: [
          Container(
            decoration: BoxDecoration(
              image: new DecorationImage(
                image: ExactAssetImage("images/TextRpgBg.jpg"),
                fit: BoxFit.cover,
              ),
            ),
          ),
          SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Center(
                child: Column(
                  children: [
                    SizedBox(
                      height: 80,
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Text(
                        'Unfortunately, life had other plans in mind for Arthur.\n\nUnbeknownst to Arthur, a pair of menacing eyes lingered on his back seemingly viewing Arthur as a fat sheep ripe for the picking. Waiting for the traffic light to turn green, Arthur stood still, unaware of the actions of the man standing directly behind him.\n\nThe man reached out with him grimy hands, slowly and carefully towards the back pocket on Arthur’s coat, reaching for the wallet.\n\nUnfortunately for the man, Arthur felt a shift in his coat, whipping his head around, he immediately realised what has happened! His wallet had been stolen and it was right in the hands of the man who stood behind him!\n\nWanting to prevent the man from escaping, Arthur reached out with his hands to grab a hold of the man’s arm and successfully manages to do so, taking advantage of the man’s state of panic.\n\nThe gruff man, in his panic induced state, put up a great struggle. “Let me go or else!” shouted the man as he hammered away at Arthur’s arms.\n\nArthur felt a sharp bolt of pain, radiating through his arms, causing him to let go of the gruff man. However, Arthur was unwilling to get the man get away with his wallet that easily.\n\nWith the rush of adrenaline dulling the pain, Arthur rushes forward, crashing his entire bodyweight into the man while grappling and headbutting his waist, knocking the breath out of him.',
                        style: TextStyle(
                          fontSize: 26,
                          fontFamily: 'SourceSansPro',
                          height: 1.5,
                        ),
                        textAlign: TextAlign.justify,
                      ),
                    ),
                    SizedBox(
                      height: 30,
                    ),

                    /////////////////////////////////////////////////////////////////////////
                    //button options to choose from to change the storyline
                    // MaterialButton(
                    //   padding: EdgeInsets.all(8.0),
                    //   textColor: Colors.black,
                    //   splashColor: Colors.black54,
                    //   elevation: 10.0,
                    //   child: Container(
                    //     height: 65,
                    //     width: 350,
                    //     decoration: BoxDecoration(
                    //       image: DecorationImage(
                    //           image: AssetImage('images/scrollbutton.png'),
                    //           fit: BoxFit.fill),
                    //       boxShadow: <BoxShadow>[
                    //         BoxShadow(
                    //           color: Colors.black.withOpacity(0.6),
                    //           blurRadius: 10,
                    //           offset: Offset(0, 6),
                    //         ),
                    //       ],
                    //     ),
                    //     child: Row(
                    //       mainAxisAlignment: MainAxisAlignment.center,
                    //       crossAxisAlignment: CrossAxisAlignment.center,
                    //       children: [
                    //         Padding(
                    //           padding: const EdgeInsets.all(8.0),
                    //           child: Text(
                    //             "This is a button",
                    //             style: TextStyle(fontSize: 20),
                    //           ),
                    //         ),
                    //       ],
                    //     ),
                    //   ),
                    //   // ),
                    //   onPressed: () {
                    //     print('Tapped');
                    //   },
                    // ),
                    SizedBox(
                      height: 30,
                    ),

                    /////////////////////////////////////////////////////////////////////////
                    //back and next button make sure to edit the routes
                    Row(
                      mainAxisAlignment: MainAxisAlignment
                          .center, //Center Row contents horizontally,
                      crossAxisAlignment: CrossAxisAlignment
                          .center, //Center Row contents vertically,
                      children: [
                        ElevatedButton(
                          style: ButtonStyle(
                            backgroundColor: MaterialStateProperty.all<Color>(
                                Colors.transparent),
                          ),
                          onPressed: () {
                            Navigator.push(context,
                                MaterialPageRoute(builder: (_) => Screen2()));
                          },
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(
                                Icons.arrow_left,
                                size: 30,
                              ),
                              Text(
                                "back",
                                style: TextStyle(
                                  fontWeight: FontWeight.w700,
                                  fontSize: 26,
                                  fontFamily: 'SourceSansPro',
                                  color: Colors.black,
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          width: 144,
                        ),
                        ElevatedButton(
                          style: ButtonStyle(
                            backgroundColor: MaterialStateProperty.all<Color>(
                                Colors.transparent),
                          ),
                          onPressed: () {
                            Navigator.push(context,
                                MaterialPageRoute(builder: (_) => Screen4()));
                          },
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text(
                                "next",
                                style: TextStyle(
                                  fontWeight: FontWeight.w700,
                                  fontSize: 26,
                                  fontFamily: 'SourceSansPro',
                                  color: Colors.black,
                                ),
                              ),
                              Icon(
                                Icons.arrow_right,
                                size: 30,
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    SizedBox(
                      height: 10,
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}