import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:text_based_rpg/main.dart';
import 'package:text_based_rpg/models/character.dart';
import 'package:text_based_rpg/provider/character_provider.dart';
import 'package:text_based_rpg/screens/screen10.dart';
import 'package:text_based_rpg/screens/screen11.dart';
import 'package:text_based_rpg/screens/screen6.dart';
import 'package:text_based_rpg/screens/screen7.dart';

class EndScreen extends StatefulWidget {
  static String routeName = '/endscreen';

  @override
  State<EndScreen> createState() => _EndScreenState();
}

class _EndScreenState extends State<EndScreen> {
  @override
  Widget build(BuildContext context) {
    CharacterProvider characterList = Provider.of<CharacterProvider>(context);
    List<Character> character = characterList.getCharacterList();

    return Scaffold(
      body: Stack(
        children: [
          Container(
            decoration: BoxDecoration(
              image: new DecorationImage(
                image: ExactAssetImage("images/TextRpgBg.jpg"),
                fit: BoxFit.cover,
              ),
            ),
          ),
          SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Center(
                child: Column(
                  children: [
                    SizedBox(
                      height: 80,
                    ),

                    // if (character[0].screen11Choice == 'Ask About the Anveron forest') ...[
                    //   Column(
                    //     children: [
                    //       Padding(
                    //         padding: const EdgeInsets.all(8.0),
                    //         child: Text(
                    //           'Realising that 12 year old Arthur\'s memories did not contain much information regarding the Anveron forest and the events that occured after the accident, Arthur decided to remain and ask.\n\n "Father, what happened in the Anveron forest? I seem to be unanle to recall what happened."\n\nHearing Arthur\'s question, Aaron white started frown and pinch his eyebrows before replying.\n\n"Arthur, it was no ordinary accident, but an ambush at your life! It seems that an unruly force has entered the borders of our fief and nearly managed to assassinate you with a knockout spell.\n\nThankfully the head guard petrolling the outer rim of the Anveron forest witnessed the spellcaster\'s sneaky behaviour and managed to grab your unconscious body and fled."',
                    //           style: TextStyle(
                    //             fontSize: 26,
                    //             fontFamily: 'SourceSansPro',
                    //             height: 1.5,
                    //           ),
                    //           textAlign: TextAlign.justify,
                    //         ),
                    //       ),
                    //       Image.asset('images/class_wizard.png'),
                    //     ],
                    //   ),
                    //
                    // ] else if (character[0].screen11Choice == 'Request for permission') ...[
                    //   Padding(
                    //     padding: const EdgeInsets.all(8.0),
                    //     child: Text(
                    //       'Understanding how little he knew about this world, Arthur decided to make a request.\n\n"Father i would like to make use of the library to learn more. Please grant me the permission to enterr the library."\n\n Arthur understood from his inhereted memories that the library contains books regarding the general knowledge of the world. Arthur also wanted tto look into the phenomenon termed as "magic" in his memories.',
                    //       style: TextStyle(
                    //         fontSize: 26,
                    //         fontFamily: 'SourceSansPro',
                    //         height: 1.5,
                    //       ),
                    //       textAlign: TextAlign.justify,
                    //     ),
                    //   ),
                    // ] else ...[
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text(
                          'Realising that further conversation would not serve any purpose, Arthur decided to make his way to the exit and leave the study room.\n\nAfter Arthur had left the room, Aaron white sighed, speaking to himself,\n\n"Looks like things are getting messy, i should consider sending Arthur to either a school of magic or one for great warriors to keep him safe while i still can."',
                          style: TextStyle(
                            fontSize: 26,
                            fontFamily: 'SourceSansPro',
                            height: 1.5,
                          ),
                          textAlign: TextAlign.justify,
                        ),
                      ),
                    // ],

                    SizedBox(
                      height: 30,
                    ),

                    Text('THE END OF CHAPTER 1',textAlign: TextAlign.center, style: TextStyle(fontSize: 33),),
                    SizedBox(
                      height: 30,
                    ),

                    /////////////////////////////////////////////////////////////////////////
                    // button options to choose from to change the storyline
                    MaterialButton(
                      padding: EdgeInsets.all(8.0),
                      textColor: Colors.black,
                      splashColor: Colors.black54,
                      elevation: 10.0,
                      child: Container(
                        height: 70,
                        width: 350,
                        decoration: BoxDecoration(
                          image: DecorationImage(
                              image: AssetImage('images/scrollbutton.png'),
                              fit: BoxFit.fill),
                          boxShadow: <BoxShadow>[
                            BoxShadow(
                              color: Colors.black.withOpacity(0.6),
                              blurRadius: 10,
                              offset: Offset(0, 6),
                            ),
                          ],
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Text(
                                "Return to Home",
                                style: TextStyle(
                                  fontSize: 21,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      // ),
                      onPressed: () {
                        Navigator.push(context, MaterialPageRoute(builder: (_) => MainScreen()));
                        character[0].screen11Choice = 'Ask About the Anveron forest';
                      },
                    ),
                    SizedBox(height: 40,),
                    // MaterialButton(
                    //   padding: EdgeInsets.all(8.0),
                    //   textColor: Colors.black,
                    //   splashColor: Colors.black54,
                    //   elevation: 10.0,
                    //   child: Container(
                    //     height: 65,
                    //     width: 350,
                    //     decoration: BoxDecoration(
                    //       image: DecorationImage(
                    //         // colorFilter: ColorFilter. mode(Colors. black. withOpacity(0.3),BlendMode.darken),
                    //           image: AssetImage('images/scrollbutton.png'),
                    //           fit: BoxFit.fill),
                    //       boxShadow: <BoxShadow>[
                    //         BoxShadow(
                    //           color: Colors.black.withOpacity(0.6),
                    //           blurRadius: 10,
                    //           offset: Offset(0, 6),
                    //         ),
                    //       ],
                    //     ),
                    //     child: Row(
                    //       mainAxisAlignment: MainAxisAlignment.center,
                    //       crossAxisAlignment: CrossAxisAlignment.center,
                    //       children: [
                    //         Padding(
                    //           padding: const EdgeInsets.all(8.0),
                    //           child: Text(
                    //             "Request for permisson to\nuse the library",
                    //             textAlign: TextAlign.center,
                    //             style: TextStyle(
                    //               fontSize: 21,
                    //             ),
                    //           ),
                    //         ),
                    //       ],
                    //     ),
                    //   ),
                    //   // ),
                    //   onPressed: () {
                    //     Navigator.push(context, MaterialPageRoute(builder: (_) => Screen12()));
                    //     character[0].screen11Choice = 'Request for permission';
                    //   },
                    // ),
                    // MaterialButton(
                    //   padding: EdgeInsets.all(8.0),
                    //   textColor: Colors.black,
                    //   splashColor: Colors.black54,
                    //   elevation: 10.0,
                    //   child: Container(
                    //     height: 55,
                    //     width: 320,
                    //     decoration: BoxDecoration(
                    //       image: DecorationImage(
                    //         // colorFilter: ColorFilter. mode(Colors. black. withOpacity(0.3),BlendMode.darken),
                    //           image: AssetImage('images/scrollbutton.png'),
                    //           fit: BoxFit.fill),
                    //       boxShadow: <BoxShadow>[
                    //         BoxShadow(
                    //           color: Colors.black.withOpacity(0.6),
                    //           blurRadius: 10,
                    //           offset: Offset(0, 6),
                    //         ),
                    //       ],
                    //     ),
                    //     child: Row(
                    //       mainAxisAlignment: MainAxisAlignment.center,
                    //       crossAxisAlignment: CrossAxisAlignment.center,
                    //       children: [
                    //         Padding(
                    //           padding: const EdgeInsets.all(8.0),
                    //           child: Text(
                    //             "Leave the Study room.",
                    //             textAlign: TextAlign.center,
                    //             style: TextStyle(
                    //               fontSize: 22,
                    //             ),
                    //           ),
                    //         ),
                    //       ],
                    //     ),
                    //   ),
                    //   // ),
                    //   onPressed: () {
                    //     Navigator.push(context, MaterialPageRoute(builder: (_) => Screen12()));
                    //     character[0].screen11Choice = 'Leave the Study room';
                    //   },
                    // ),
                    // SizedBox(
                    //   height: 30,
                    // ),

                    /////////////////////////////////////////////////////////////////////////
                    //back and next button make sure to edit the routes

                    //BACKKK BUTTON
                    Row(
                      mainAxisAlignment: MainAxisAlignment
                          .center, //Center Row contents horizontally,
                      crossAxisAlignment: CrossAxisAlignment
                          .center, //Center Row contents vertically,
                      children: [
                        ElevatedButton(
                          style: ButtonStyle(
                            backgroundColor: MaterialStateProperty.all<Color>(
                                Colors.transparent),
                          ),
                          onPressed: () {
                            Navigator.push(context,
                                MaterialPageRoute(builder: (_) => Screen11()));
                          },
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(
                                Icons.arrow_left,
                                size: 30,
                              ),
                              Text(
                                "back",
                                style: TextStyle(
                                  fontWeight: FontWeight.w700,
                                  fontSize: 26,
                                  fontFamily: 'SourceSansPro',
                                  color: Colors.black,
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          // width: 144,
                          width: 225,
                        ),
                        // ElevatedButton(
                        //   style: ButtonStyle(
                        //     backgroundColor: MaterialStateProperty.all<Color>(
                        //         Colors.transparent),
                        //   ),
                        //   onPressed: () {
                        //     Navigator.push(context,
                        //         MaterialPageRoute(builder: (_) => Screen6()));
                        //   },
                        //   child: Row(
                        //     mainAxisSize: MainAxisSize.min,
                        //     children: [
                        //       Text(
                        //         "next",
                        //         style: TextStyle(
                        //           fontWeight: FontWeight.w700,
                        //           fontSize: 26,
                        //           fontFamily: 'SourceSansPro',
                        //           color: Colors.black,
                        //         ),
                        //       ),
                        //       Icon(
                        //         Icons.arrow_right,
                        //         size: 30,
                        //       ),
                        //     ],
                        //   ),
                        // ),
                      ],
                    ),
                    SizedBox(
                      height: 10,
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
