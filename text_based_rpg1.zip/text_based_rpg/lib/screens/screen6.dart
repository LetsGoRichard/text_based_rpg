import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:text_based_rpg/models/character.dart';
import 'package:text_based_rpg/provider/character_provider.dart';
import 'package:text_based_rpg/screens/screen5.dart';
import 'package:text_based_rpg/screens/screen7.dart';

class Screen6 extends StatefulWidget {
  static String routeName = '/screen5';

  @override
  State<Screen6> createState() => _Screen6State();
}

class _Screen6State extends State<Screen6> {
  @override
  Widget build(BuildContext context) {
    CharacterProvider characterList = Provider.of<CharacterProvider>(context);
    List<Character> character = characterList.getCharacterList();

    return Scaffold(
      body: Stack(
        children: [
          Container(
            decoration: BoxDecoration(
              image: new DecorationImage(
                image: ExactAssetImage("images/TextRpgBg.jpg"),
                fit: BoxFit.cover,
              ),
            ),
          ),
          SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Center(
                child: Column(
                  children: [
                    SizedBox(
                      height: 80,
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Text(
                        '"Ugh! My head... it still hurts! Darn that thief...with how strong he was, he should have become a professional athlete instead."\n\nArthur pried his eyes open despite his headache, taking a brief look of his surroundings.\n\n"What ward am i in anyways? I\'ve never seen such a fancy ward in a hospital before... the bed im on too...it seems larger than a king sized mattress!"\n\nJust as Arthur decided to move over to the edge of the bed to climb and explore the room, three rapid knocks on the large wooden door interrupted Arthur.',
                        style: TextStyle(
                          fontSize: 26,
                          fontFamily: 'SourceSansPro',
                          height: 1.5,
                        ),
                        textAlign: TextAlign.justify,
                      ),
                    ),
                    Image.asset('images/castle_room_door1.png'),

                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Text(
                        '"Young Lord, are you awake...? Who am i kidding, the young lord is probably still injured and is resting."\n\nThe door creaks open and someone who can only be described as a maid steps through the door, preparing to check up on Arthur\'s condition.\n\n "Huh? Is that a nurse in a maid\'s outfit?"\n\nArthur was stunned by what he was seeing. A young girl that was barely over the age of 12 was wearing a maid\'s outfit while carrying a plate of warm towels and a small basin of water.\n\nWith her vision covered by the pile of towels, coupled with her short stature, the poor girl did not notice that Arthur was in fact awake and was sitting at the edge of the bed, right in front of her.',
                        style: TextStyle(
                          fontSize: 26,
                          fontFamily: 'SourceSansPro',
                          height: 1.5,
                        ),
                        textAlign: TextAlign.justify,
                      ),
                    ),
                    SizedBox(
                      height: 30,
                    ),

                    /////////////////////////////////////////////////////////////////////////
                    // button options to choose from to change the storyline
                    MaterialButton(
                      padding: EdgeInsets.all(8.0),
                      textColor: Colors.black,
                      splashColor: Colors.black54,
                      elevation: 10.0,
                      child: Container(
                        height: 55,
                        width: 350,
                        decoration: BoxDecoration(
                          image: DecorationImage(
                              image: AssetImage('images/scrollbutton.png'),
                              fit: BoxFit.fill),
                          boxShadow: <BoxShadow>[
                            BoxShadow(
                              color: Colors.black.withOpacity(0.6),
                              blurRadius: 10,
                              offset: Offset(0, 6),
                            ),
                          ],
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Text(
                                "Call out to the girl",
                                style: TextStyle(
                                  fontSize: 22,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      // ),
                      onPressed: () {
                        Navigator.push(context,
                            MaterialPageRoute(builder: (_) => Screen7()));
                        character[0].screen6Choice = 'Call out to the girl';
                      },
                    ),
                    MaterialButton(
                      padding: EdgeInsets.all(8.0),
                      textColor: Colors.black,
                      splashColor: Colors.black54,
                      elevation: 10.0,
                      child: Container(
                        height: 55,
                        width: 350,
                        decoration: BoxDecoration(
                          image: DecorationImage(
                              image: AssetImage('images/scrollbutton.png'),
                              fit: BoxFit.fill),
                          boxShadow: <BoxShadow>[
                            BoxShadow(
                              color: Colors.black.withOpacity(0.6),
                              blurRadius: 10,
                              offset: Offset(0, 6),
                            ),
                          ],
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Text(
                                "Say nothing and stay slient",
                                style: TextStyle(
                                  fontSize: 22,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      // ),
                      onPressed: () {
                        Navigator.push(context,
                            MaterialPageRoute(builder: (_) => Screen7()));
                        character[0].screen6Choice =
                            'Say nothing and stay slient';
                      },
                    ),
                    SizedBox(
                      height: 30,
                    ),

                    /////////////////////////////////////////////////////////////////////////
                    //back and next button make sure to edit the routes
                    Row(
                      mainAxisAlignment: MainAxisAlignment
                          .center, //Center Row contents horizontally,
                      crossAxisAlignment: CrossAxisAlignment
                          .center, //Center Row contents vertically,
                      children: [
                        ElevatedButton(
                          style: ButtonStyle(
                            backgroundColor: MaterialStateProperty.all<Color>(
                                Colors.transparent),
                          ),
                          onPressed: () {
                            Navigator.push(context,
                                MaterialPageRoute(builder: (_) => Screen5()));
                          },
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(
                                Icons.arrow_left,
                                size: 30,
                              ),
                              Text(
                                "back",
                                style: TextStyle(
                                  fontWeight: FontWeight.w700,
                                  fontSize: 26,
                                  fontFamily: 'SourceSansPro',
                                  color: Colors.black,
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          // width: 144,
                          width: 225,
                        ),
                        // ElevatedButton(
                        //   style: ButtonStyle(
                        //     backgroundColor: MaterialStateProperty.all<Color>(
                        //         Colors.transparent),
                        //   ),
                        //   onPressed: () {
                        //     Navigator.push(context,
                        //         MaterialPageRoute(builder: (_) => Screen6()));
                        //   },
                        //   child: Row(
                        //     mainAxisSize: MainAxisSize.min,
                        //     children: [
                        //       Text(
                        //         "next",
                        //         style: TextStyle(
                        //           fontWeight: FontWeight.w700,
                        //           fontSize: 26,
                        //           fontFamily: 'SourceSansPro',
                        //           color: Colors.black,
                        //         ),
                        //       ),
                        //       Icon(
                        //         Icons.arrow_right,
                        //         size: 30,
                        //       ),
                        //     ],
                        //   ),
                        // ),
                      ],
                    ),
                    SizedBox(
                      height: 10,
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
