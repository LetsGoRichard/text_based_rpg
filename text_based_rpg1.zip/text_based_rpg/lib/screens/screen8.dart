import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:text_based_rpg/models/character.dart';
import 'package:text_based_rpg/provider/character_provider.dart';
import 'package:text_based_rpg/screens/screen6.dart';
import 'package:text_based_rpg/screens/screen7.dart';
import 'package:text_based_rpg/screens/screen9.dart';



class Screen8 extends StatefulWidget {
  static String routeName = '/screen8';

  @override
  State<Screen8> createState() => _Screen8State();
}

class _Screen8State extends State<Screen8> {
  @override
  Widget build(BuildContext context) {
    CharacterProvider characterList = Provider.of<CharacterProvider>(context);
    List<Character> character = characterList.getCharacterList();

    return Scaffold(
      body: Stack(
        children: [
          Container(
            decoration: BoxDecoration(
              image: new DecorationImage(
                image: ExactAssetImage("images/TextRpgBg.jpg"),
                fit: BoxFit.cover,
              ),
            ),
          ),
          SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Center(
                child: Column(
                  children: [
                    SizedBox(
                      height: 80,
                    ),

                    if (character[0].screen7Choice == 'Get the girl to help you up') ...[
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text(
                          '"Little girl, could you give me some help here? I want to get up and walk a for abit..."\n\n "Ah! my lord this servant thinks it is unwise for the lord to get up yet, the lord should continue to rest and recover."\n\n"Forgive this servant for not knowing the \'horsepital\' the lord speaks of! you took a great fall in the Anveron Forest which hurt your head and left you injured and unconscious."\n\nThe little girl knelt while recounting the situation to Arthur, much like how a medieval servant treats their master.',
                          style: TextStyle(
                            fontSize: 26,
                            fontFamily: 'SourceSansPro',
                            height: 1.5,
                          ),
                          textAlign: TextAlign.justify,
                        ),
                      ),
                    ] else ...[
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text(
                          'Stunned by Arthur\'s questions, the little girl tilted her head slightly and gave Arthur a quizzical look.\n\n "My lord, are you alright? What is this \'horsespital\' you speak of?\n\n Ah i got it! You must still be confused after the bad fall you had in the Anveron Forest, after all you did injure your head quite badly and became unconscious."\n\nThe little girl knelt while recounting the situation to Arthur, much like how a medieval servant treats their master.',
                          style: TextStyle(
                            fontSize: 26,
                            fontFamily: 'SourceSansPro',
                            height: 1.5,
                          ),
                          textAlign: TextAlign.justify,
                        ),
                      ),
                    ],

                    SizedBox(
                      height: 30,
                    ),

                    /////////////////////////////////////////////////////////////////////////
                    // button options to choose from to change the storyline
                    MaterialButton(
                      padding: EdgeInsets.all(8.0),
                      textColor: Colors.black,
                      splashColor: Colors.black54,
                      elevation: 10.0,
                      child: Container(
                        height: 55,
                        width: 350,
                        decoration: BoxDecoration(
                          image: DecorationImage(
                              image: AssetImage('images/scrollbutton.png'),
                              fit: BoxFit.fill),
                          boxShadow: <BoxShadow>[
                            BoxShadow(
                              color: Colors.black.withOpacity(0.6),
                              blurRadius: 10,
                              offset: Offset(0, 6),
                            ),
                          ],
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Text(
                                "Lord? Calling me a Lord?",
                                style: TextStyle(fontSize: 22,),
                              ),
                            ),
                          ],
                        ),
                      ),
                      // ),
                      onPressed: () {
                        Navigator.push(context, MaterialPageRoute(builder: (_) => Screen9()));
                        character[0].screen8Choice = 'Lord? Calling me a Lord?';
                      },
                    ),
                    MaterialButton(
                      padding: EdgeInsets.all(8.0),
                      textColor: Colors.black,
                      splashColor: Colors.black54,
                      elevation: 10.0,
                      child: Container(
                        height: 55,
                        width: 350,
                        decoration: BoxDecoration(
                          image: DecorationImage(
                              colorFilter: ColorFilter. mode(Colors. black. withOpacity(0.3),BlendMode.darken),
                              image: AssetImage('images/scrollbutton.png'),
                              fit: BoxFit.fill),
                          boxShadow: <BoxShadow>[
                            BoxShadow(
                              color: Colors.black.withOpacity(0.6),
                              blurRadius: 10,
                              offset: Offset(0, 6),
                            ),
                          ],
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Text(
                                "Where am i?",
                                style: TextStyle(fontSize: 22,),
                              ),
                            ),
                          ],
                        ),
                      ),
                      // ),
                      onPressed: () {
                        // Navigator.push(context, MaterialPageRoute(builder: (_) => Screen8()));
                        // character[0].screen7Choice = 'Get the girl to help you up';
                      },
                    ),
                    SizedBox(
                      height: 30,
                    ),

                    /////////////////////////////////////////////////////////////////////////
                    //back and next button make sure to edit the routes

                    //BACKKK BUTTON
                    Row(
                      mainAxisAlignment: MainAxisAlignment
                          .center, //Center Row contents horizontally,
                      crossAxisAlignment: CrossAxisAlignment
                          .center, //Center Row contents vertically,
                      children: [
                        ElevatedButton(
                          style: ButtonStyle(
                            backgroundColor: MaterialStateProperty.all<Color>(
                                Colors.transparent),
                          ),
                          onPressed: () {
                            Navigator.push(context,
                                MaterialPageRoute(builder: (_) => Screen7()));
                          },
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(
                                Icons.arrow_left,
                                size: 30,
                              ),
                              Text(
                                "back",
                                style: TextStyle(
                                  fontWeight: FontWeight.w700,
                                  fontSize: 26,
                                  fontFamily: 'SourceSansPro',
                                  color: Colors.black,
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          // width: 144,
                          width: 225,
                        ),
                        // ElevatedButton(
                        //   style: ButtonStyle(
                        //     backgroundColor: MaterialStateProperty.all<Color>(
                        //         Colors.transparent),
                        //   ),
                        //   onPressed: () {
                        //     Navigator.push(context,
                        //         MaterialPageRoute(builder: (_) => Screen6()));
                        //   },
                        //   child: Row(
                        //     mainAxisSize: MainAxisSize.min,
                        //     children: [
                        //       Text(
                        //         "next",
                        //         style: TextStyle(
                        //           fontWeight: FontWeight.w700,
                        //           fontSize: 26,
                        //           fontFamily: 'SourceSansPro',
                        //           color: Colors.black,
                        //         ),
                        //       ),
                        //       Icon(
                        //         Icons.arrow_right,
                        //         size: 30,
                        //       ),
                        //     ],
                        //   ),
                        // ),
                      ],
                    ),
                    SizedBox(
                      height: 10,
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}