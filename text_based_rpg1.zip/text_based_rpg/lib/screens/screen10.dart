import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:text_based_rpg/models/character.dart';
import 'package:text_based_rpg/provider/character_provider.dart';
import 'package:text_based_rpg/screens/screen11.dart';
import 'package:text_based_rpg/screens/screen9.dart';



class Screen10 extends StatefulWidget {
  static String routeName = '/screen10';

  @override
  State<Screen10> createState() => _Screen10State();
}

class _Screen10State extends State<Screen10> {
  @override
  Widget build(BuildContext context) {
    CharacterProvider characterList = Provider.of<CharacterProvider>(context);
    List<Character> character = characterList.getCharacterList();

    return Scaffold(
      body: Stack(
        children: [
          Container(
            decoration: BoxDecoration(
              image: new DecorationImage(
                image: ExactAssetImage("images/TextRpgBg.jpg"),
                fit: BoxFit.cover,
              ),
            ),
          ),
          SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Center(
                child: Column(
                  children: [
                    SizedBox(
                      height: 80,
                    ),

                    if (character[0].screen9Choice == 'Where am i?') ...[
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text(
                          '"I see, I totally understand now... LIKE HECK I DO!\n\nWhere is this place and why did you keep me here instead of sending me to a hospital?! This is insane...what is going on..." Frightened by Arthur\'s sudden outburst, The little girl immediately prostrates herself, infront of Arthur\'s feet.\n\n"Please calm down my lord! Punish this servant whatever she has done wrong!"\n\n"Stand up young lady, stop lowering yourself like that! And also, what is your name?"\n\nStanding back up, Ania couldn\'t help but think that the fall might have resulted in some serious memory loss. Not wanting to anger Arthur any further, Ania quickly blurts out "This humble servant\'s name is Ania"\n\n"I see, Ania... Give me a moment Ania, let me try and recall some things"\n\nBreathing deeply to calm himself down, Arthur slumps back onto the bed and shuts his eye, trying his best to recall any memories he might have of what happened after the brutal beating he received from the thief.\n\nThe more Arthur tried to remember, the worse his headache became. All of a sudden, his headache intensified by multiple folds, clutching his head, Arthur groans and winces, trashing about on the bed, losing control over his arms and legs.\n\nMemories that Arthur has never seen before started to emerge, pouring in like a tidal wave, with no end in sight.\n\nPanicking and unsure of what is happening, Ania paced around the bed shouting "My Lord! Please stop hurting yourself! Are you in pain?" as she tried to hold Arthur down to prevent his arms and legs from hitting each other. After a couple angonising minutes, the pain subsided and Arthur regained control over his body.\n\nRealising that Arthur is now back to normal, Ania gives a sigh of relief. Armed with his new found memories, Arthur pieced together the situation and realised the predicament or should he say "blessing" that he is in.\n\n"as absurd as it sounds, i seem to have transmigrated into another world into the body of Arthur White, a nobel\'s son, where his father is the owner of a small fief in the northen side of the kingdom of Gracia. Somehow, Arthur and i share the exact same name, it is just that he seems to have been younger than me."\n\nTaking a good look at his current body Arthur realises that he is in the body of a 12 year old, short brown hair, deep emerald eyes, light coloured skin and a bony frame, dressed in a white tunic with silken pants.\n\n"My lord, now that you have settled down, i shall inform your father, that you are awake."\n\nBefore Arthur could ask any further questions, Aina bows and exits the room, travelling down the hallway towards the study-room where \'father\' presumably is.',
                          style: TextStyle(
                            fontSize: 26,
                            fontFamily: 'SourceSansPro',
                            height: 1.5,
                          ),
                          textAlign: TextAlign.justify,
                        ),
                      ),
                    ] else ...[
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text(
                          '',
                          style: TextStyle(
                            fontSize: 26,
                            fontFamily: 'SourceSansPro',
                            height: 1.5,
                          ),
                          textAlign: TextAlign.justify,
                        ),
                      ),
                    ],
                    Image.asset('images/castle_hallway1.png'),

                    SizedBox(
                      height: 30,
                    ),

                    /////////////////////////////////////////////////////////////////////////
                    // button options to choose from to change the storyline
                    MaterialButton(
                      padding: EdgeInsets.all(8.0),
                      textColor: Colors.black,
                      splashColor: Colors.black54,
                      elevation: 10.0,
                      child: Container(
                        height: 65,
                        width: 350,
                        decoration: BoxDecoration(
                          image: DecorationImage(
                              // colorFilter: ColorFilter. mode(Colors. black. withOpacity(0.3),BlendMode.darken),
                              image: AssetImage('images/scrollbutton.png'),
                              fit: BoxFit.fill),
                          boxShadow: <BoxShadow>[
                            BoxShadow(
                              color: Colors.black.withOpacity(0.6),
                              blurRadius: 10,
                              offset: Offset(0, 6),
                            ),
                          ],
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Text(
                                "Freshen up before heading to\nthe study-room",textAlign: TextAlign.center,
                                style: TextStyle(fontSize: 20,),
                              ),
                            ),
                          ],
                        ),
                      ),
                      // ),
                      onPressed: () {
                        Navigator.push(context, MaterialPageRoute(builder: (_) => Screen11()));
                        character[0].screen10Choice = 'Freshen up';
                      },
                    ),
                    MaterialButton(
                      padding: EdgeInsets.all(8.0),
                      textColor: Colors.black,
                      splashColor: Colors.black54,
                      elevation: 10.0,
                      child: Container(
                        height: 55,
                        width: 350,
                        decoration: BoxDecoration(
                          image: DecorationImage(
                              image: AssetImage('images/scrollbutton.png'),
                              fit: BoxFit.fill),
                          boxShadow: <BoxShadow>[
                            BoxShadow(
                              color: Colors.black.withOpacity(0.6),
                              blurRadius: 10,
                              offset: Offset(0, 6),
                            ),
                          ],
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Text(
                                "Stay and familiarise memories",
                                style: TextStyle(fontSize: 21,),
                              ),
                            ),
                          ],
                        ),
                      ),
                      // ),
                      onPressed: () {
                        Navigator.push(context, MaterialPageRoute(builder: (_) => Screen11()));
                        character[0].screen10Choice = 'familiarise memories';
                      },
                    ),
                    SizedBox(
                      height: 30,
                    ),

                    /////////////////////////////////////////////////////////////////////////
                    //back and next button make sure to edit the routes

                    //BACKKK BUTTON
                    Row(
                      mainAxisAlignment: MainAxisAlignment
                          .center, //Center Row contents horizontally,
                      crossAxisAlignment: CrossAxisAlignment
                          .center, //Center Row contents vertically,
                      children: [
                        ElevatedButton(
                          style: ButtonStyle(
                            backgroundColor: MaterialStateProperty.all<Color>(
                                Colors.transparent),
                          ),
                          onPressed: () {
                            Navigator.push(context,
                                MaterialPageRoute(builder: (_) => Screen9()));
                          },
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(
                                Icons.arrow_left,
                                size: 30,
                              ),
                              Text(
                                "back",
                                style: TextStyle(
                                  fontWeight: FontWeight.w700,
                                  fontSize: 26,
                                  fontFamily: 'SourceSansPro',
                                  color: Colors.black,
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          // width: 144,
                          width: 225,
                        ),
                        // ElevatedButton(
                        //   style: ButtonStyle(
                        //     backgroundColor: MaterialStateProperty.all<Color>(
                        //         Colors.transparent),
                        //   ),
                        //   onPressed: () {
                        //     Navigator.push(context,
                        //         MaterialPageRoute(builder: (_) => Screen6()));
                        //   },
                        //   child: Row(
                        //     mainAxisSize: MainAxisSize.min,
                        //     children: [
                        //       Text(
                        //         "next",
                        //         style: TextStyle(
                        //           fontWeight: FontWeight.w700,
                        //           fontSize: 26,
                        //           fontFamily: 'SourceSansPro',
                        //           color: Colors.black,
                        //         ),
                        //       ),
                        //       Icon(
                        //         Icons.arrow_right,
                        //         size: 30,
                        //       ),
                        //     ],
                        //   ),
                        // ),
                      ],
                    ),
                    SizedBox(
                      height: 10,
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}