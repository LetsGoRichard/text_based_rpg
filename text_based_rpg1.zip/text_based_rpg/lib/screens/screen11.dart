import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:text_based_rpg/models/character.dart';
import 'package:text_based_rpg/provider/character_provider.dart';
import 'package:text_based_rpg/screens/screen%2012.dart';
import 'package:text_based_rpg/screens/screen10.dart';
import 'package:text_based_rpg/screens/screen6.dart';
import 'package:text_based_rpg/screens/screen7.dart';

import 'end_screen.dart';



class Screen11 extends StatefulWidget {
  static String routeName = '/screen11';

  @override
  State<Screen11> createState() => _Screen11State();
}

class _Screen11State extends State<Screen11> {
  @override
  Widget build(BuildContext context) {
    CharacterProvider characterList = Provider.of<CharacterProvider>(context);
    List<Character> character = characterList.getCharacterList();

    return Scaffold(
      body: Stack(
        children: [
          Container(
            decoration: BoxDecoration(
              image: new DecorationImage(
                image: ExactAssetImage("images/TextRpgBg.jpg"),
                fit: BoxFit.cover,
              ),
            ),
          ),
          SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Center(
                child: Column(
                  children: [
                    SizedBox(
                      height: 80,
                    ),

                    if (character[0].screen10Choice == 'Freshen up') ...[
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text(
                          'Seeing his current dishevelled state, Arthur decides to freshen himself up quickly along with a change of clothes, changing into a long-sleeved waistcoat before heading out the room into the sunlit hallways.\n\nThe long hallway to the study room gave Arthur some time to collect his thoughts. Without realising, Arthur\'s hand instinctively gave 3 curt knocks on the imposing door.\n\n"Come in, Arthur."\n\nSteeling his mind, Arthur took the plunge and entered into the study room. A well lit room, high ceilings and shelves of books covered Arthur\'s vision, not to mention the bear of a man sitting infront of a table with piles of documents scattered by his side.\n\nFollowing the actions instilled into the previous Arthur, Arthur White greeted and bowed.\n\n"Father."\n\n"Dispense with the formalities, you have just recovered. I am glad to see that you have recovered enough to stand before me.\n\nAina has mentioned to me that you are still slightly disoriented and that you will need more rest.\n\nDo you have anything to ask? If not, you are free to leave and rest."',
                          style: TextStyle(
                            fontSize: 26,
                            fontFamily: 'SourceSansPro',
                            height: 1.5,
                          ),
                          textAlign: TextAlign.justify,
                        ),
                      ),
                    ] else ...[
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text(
                          'Still slightly wary of his current transmigrated status, Arthur decides to remain in his bedroom for a while longer to familarise himself with \'Arthur\'s\' memories before heading to the study room.\n\nFocusing on the memories of the 12 year old Arthur, Arthur realised that despite the seemingly large amount of information, most of it was related to day to day activities of a young teenage boy with little to no knowledge of the outside world beyond his father\'s fief let alone his own father.\n\nA simple explanation would be that Arthur\'s \'father\' in this world is a busy man, with Arthur only meeting his father once a year during the harvest festival.\n\n This situation suited Arthur White a lot as he wouldn\'t have to pretend much around Aaron White, his \'father\' as Aaron White himself wouldn\'t have known little about Arthur\'s original personality.\n\nConfident in his ability to pretend as a 12 year old, Arthur promptly knocked on the study room\'s door and entered.  A well lit room, high ceilings and shelves of books covered Arthur\'s vision, not to mention the bear of a man sitting infront of a table with piles of documents scattered by his side.\n\nFollowing the actions instilled into the previous Arthur, Arthur White greeted and bowed.\n\n"Father."\n\n"Dispense with the formalities, you have just recovered. I am glad to see that you have recovered enough to stand before me.\n\nAina has mentioned to me that you are still slightly disoriented and that you will need more rest.\n\nDo you have anything to ask? If not, you are free to leave and rest."',
                          style: TextStyle(
                            fontSize: 26,
                            fontFamily: 'SourceSansPro',
                            height: 1.5,
                          ),
                          textAlign: TextAlign.justify,
                        ),
                      ),
                    ],

                    SizedBox(
                      height: 30,
                    ),

                    /////////////////////////////////////////////////////////////////////////
                    // button options to choose from to change the storyline
                    MaterialButton(
                      padding: EdgeInsets.all(8.0),
                      textColor: Colors.black,
                      splashColor: Colors.black54,
                      elevation: 10.0,
                      child: Container(
                        height: 55,
                        width: 350,
                        decoration: BoxDecoration(
                          image: DecorationImage(
                              image: AssetImage('images/scrollbutton.png'),
                              fit: BoxFit.fill),
                          boxShadow: <BoxShadow>[
                            BoxShadow(
                              color: Colors.black.withOpacity(0.6),
                              blurRadius: 10,
                              offset: Offset(0, 6),
                            ),
                          ],
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Text(
                                "Ask About the Anveron forest",
                                style: TextStyle(fontSize: 21,),
                              ),
                            ),
                          ],
                        ),
                      ),
                      // ),
                      onPressed: () {
                        Navigator.push(context, MaterialPageRoute(builder: (_) => Screen12()));
                        character[0].screen11Choice = 'Ask About the Anveron forest';
                      },
                    ),
                    MaterialButton(
                      padding: EdgeInsets.all(8.0),
                      textColor: Colors.black,
                      splashColor: Colors.black54,
                      elevation: 10.0,
                      child: Container(
                        height: 65,
                        width: 350,
                        decoration: BoxDecoration(
                          image: DecorationImage(
                              // colorFilter: ColorFilter. mode(Colors. black. withOpacity(0.3),BlendMode.darken),
                              image: AssetImage('images/scrollbutton.png'),
                              fit: BoxFit.fill),
                          boxShadow: <BoxShadow>[
                            BoxShadow(
                              color: Colors.black.withOpacity(0.6),
                              blurRadius: 10,
                              offset: Offset(0, 6),
                            ),
                          ],
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Text(
                                "Request for permission to\nuse the library",textAlign: TextAlign.center,
                                style: TextStyle(fontSize: 21,),
                              ),
                            ),
                          ],
                        ),
                      ),
                      // ),
                      onPressed: () {
                        Navigator.push(context, MaterialPageRoute(builder: (_) => Screen12()));
                        character[0].screen11Choice = 'Request for permission';
                      },
                    ),
                    MaterialButton(
                      padding: EdgeInsets.all(8.0),
                      textColor: Colors.black,
                      splashColor: Colors.black54,
                      elevation: 10.0,
                      child: Container(
                        height: 55,
                        width: 320,
                        decoration: BoxDecoration(
                          image: DecorationImage(
                            // colorFilter: ColorFilter. mode(Colors. black. withOpacity(0.3),BlendMode.darken),
                              image: AssetImage('images/scrollbutton.png'),
                              fit: BoxFit.fill),
                          boxShadow: <BoxShadow>[
                            BoxShadow(
                              color: Colors.black.withOpacity(0.6),
                              blurRadius: 10,
                              offset: Offset(0, 6),
                            ),
                          ],
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Text(
                                "Leave the Study room.",textAlign: TextAlign.center,
                                style: TextStyle(fontSize: 22,),
                              ),
                            ),
                          ],
                        ),
                      ),
                      // ),
                      onPressed: () {
                        Navigator.push(context, MaterialPageRoute(builder: (_) => EndScreen()));
                        character[0].screen11Choice = 'Leave the Study room';
                      },
                    ),
                    SizedBox(
                      height: 30,
                    ),

                    /////////////////////////////////////////////////////////////////////////
                    //back and next button make sure to edit the routes

                    //BACKKK BUTTON
                    Row(
                      mainAxisAlignment: MainAxisAlignment
                          .center, //Center Row contents horizontally,
                      crossAxisAlignment: CrossAxisAlignment
                          .center, //Center Row contents vertically,
                      children: [
                        ElevatedButton(
                          style: ButtonStyle(
                            backgroundColor: MaterialStateProperty.all<Color>(
                                Colors.transparent),
                          ),
                          onPressed: () {
                            Navigator.push(context,
                                MaterialPageRoute(builder: (_) => Screen10()));
                          },
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(
                                Icons.arrow_left,
                                size: 30,
                              ),
                              Text(
                                "back",
                                style: TextStyle(
                                  fontWeight: FontWeight.w700,
                                  fontSize: 26,
                                  fontFamily: 'SourceSansPro',
                                  color: Colors.black,
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          // width: 144,
                          width: 225,
                        ),
                        // ElevatedButton(
                        //   style: ButtonStyle(
                        //     backgroundColor: MaterialStateProperty.all<Color>(
                        //         Colors.transparent),
                        //   ),
                        //   onPressed: () {
                        //     Navigator.push(context,
                        //         MaterialPageRoute(builder: (_) => Screen6()));
                        //   },
                        //   child: Row(
                        //     mainAxisSize: MainAxisSize.min,
                        //     children: [
                        //       Text(
                        //         "next",
                        //         style: TextStyle(
                        //           fontWeight: FontWeight.w700,
                        //           fontSize: 26,
                        //           fontFamily: 'SourceSansPro',
                        //           color: Colors.black,
                        //         ),
                        //       ),
                        //       Icon(
                        //         Icons.arrow_right,
                        //         size: 30,
                        //       ),
                        //     ],
                        //   ),
                        // ),
                      ],
                    ),
                    SizedBox(
                      height: 10,
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}