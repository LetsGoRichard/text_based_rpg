class Character {
  int money;
  String name;
  String element;
  String screen6Choice;
  String screen7Choice;
  String screen8Choice;
  String screen9Choice;
  String screen10Choice;
  String screen11Choice;


  Character({
    required this.money,
    required this.name,
    required this.element,
    required this.screen6Choice,
    required this.screen7Choice,
    required this.screen8Choice,
    required this.screen9Choice,
    required this.screen10Choice,
    required this.screen11Choice,
  });

}