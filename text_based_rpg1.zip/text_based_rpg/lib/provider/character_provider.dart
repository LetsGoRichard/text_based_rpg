import 'package:flutter/material.dart';
import 'package:text_based_rpg/models/character.dart';

class CharacterProvider with ChangeNotifier{

  List <Character> characterList = [
    Character(money: 0, element: 'none', name: 'Arthur', screen6Choice: '',  screen7Choice: '',  screen8Choice: '',  screen9Choice: '',  screen10Choice: '',  screen11Choice: '', )
  ];

  List <Character> getCharacterList(){
    return characterList;
  }
}